<?php
defined('_JEXEC') or die('Restricted access'); // no direct access
require_once dirname(__FILE__) . str_replace('/', DIRECTORY_SEPARATOR, '/../../../functions.php');

$canEdit = ($this->user->authorize('com_content', 'edit', 'content', 'all') || $this->user->authorize('com_content', 'edit', 'content', 'own'));

echo artxPost(artxPageTitle($this, $this->params->get('show_page_title', 1) && $this->params->get('page_title') != $this->article->title), null);
?>
<div class="art-Post">
    <div class="art-Post-tl"></div>
    <div class="art-Post-tr"></div>
    <div class="art-Post-bl"></div>
    <div class="art-Post-br"></div>
    <div class="art-Post-tc"></div>
    <div class="art-Post-bc"></div>
    <div class="art-Post-cl"></div>
    <div class="art-Post-cr"></div>
    <div class="art-Post-cc"></div>
    <div class="art-Post-body">
<div class="art-Post-inner">
<?php
artxFragmentBegin("<div class=\"art-PostMetadataHeader\">\r\n");
if ($this->params->get('show_title')) {
 ob_start();
?>
 <h2 class="art-PostHeaderIcon-wrapper"> <span class="art-PostHeader">
<?php
 artxFragmentBegin(ob_get_clean());
 if ($this->params->get('link_titles') && $this->article->readmore_link != '')
  artxFragmentContent('<a href="' . $this->article->readmore_link . '" class="PostHeader">' . $this->escape($this->article->title) . '</a>');
 else
  artxFragmentContent($this->escape($this->article->title));
 ob_start();
?>
</span>
</h2>

<?php
 artxFragmentEnd(ob_get_clean());
}
artxFragmentEnd("\r\n</div>\r\n");
artxFragmentBegin("<div class=\"art-PostHeaderIcons art-metadata-icons\">\r\n");
if ($this->params->get('show_create_date')) {
  echo artxFragment('', JHTML::_('date', $this->article->created, JText::_('DATE_FORMAT_LC2')), '', ' | ');
}
if (($this->params->get('show_author')) && ($this->article->author != "")) {
  echo artxFragment('', JText::sprintf('Written by', ($this->article->created_by_alias ? $this->article->created_by_alias : $this->article->author)), '', ' | ');
}
if ($this->params->get('show_url') && $this->article->urls)
 artxFragment('', '<a href="http://' . $this->item->urls . '" target="_blank">' . $this->item->urls . '</a>', '', ' | ');
if (!$this->print) {
 artxFragmentBegin('<span class="art-metadata-icons">');
 if ($this->params->get('show_pdf_icon'))
  artxFragment('', JHTML::_('icon.pdf',  $this->article, $this->params, $this->access), '', '&nbsp;');
 if ($this->params->get('show_print_icon' ))
  artxFragment('', JHTML::_('icon.print_popup', $this->article, $this->params, $this->access), '', '&nbsp;');
 if ($this->params->get('show_email_icon'))
  artxFragment('', JHTML::_('icon.email', $this->article, $this->params, $this->access), '', '&nbsp;');
 artxFragmentEnd('</span>', ' | ');
 if ($canEdit)
  artxFragment('', JHTML::_('icon.edit', $this->article, $this->params, $this->access), '', ' | ');
} else
 artxFragment('', JHTML::_('icon.print_screen',  $this->article, $this->params, $this->access, array('class' => 'art-metadata-icon')), '', ' | ');
artxFragmentEnd("\r\n</div>\r\n");
echo "<div class=\"art-PostContent\">\r\n";
if (!$this->params->get('show_intro'))
 echo $this->article->event->afterDisplayTitle;
echo $this->article->event->beforeDisplayContent;
if (($this->params->get('show_section') && $this->article->sectionid) || ($this->params->get('show_category') && $this->article->catid)) {
?>
<table class="contentpaneopen<?php echo $this->params->get('pageclass_sfx' ); ?>">
<tr>
	<td>
<?php
if ($this->params->get('show_section') && $this->article->sectionid && isset($this->article->section)) {
 echo "<span>";
 if ($this->params->get('link_section'))
  echo '<a href="'.JRoute::_(ContentHelperRoute::getSectionRoute($this->article->sectionid)).'">';
 echo $this->article->section;
 if ($this->params->get('link_section'))
  echo '</a>';
 if ($this->params->get('show_category'))
  echo ' - ';
 echo "</span>";
}
if ($this->params->get('show_category') && $this->article->catid) {
 echo "<span>";
 if ($this->params->get('link_category'))
  echo '<a href="'.JRoute::_(ContentHelperRoute::getCategoryRoute($this->article->catslug, $this->article->sectionid)).'">';
 echo $this->article->category;
 if ($this->params->get('link_category'))
  echo '</a>';
 echo "</span>";
}
?>
	</td>
</tr>
</table>
<?php
}
if (isset ($this->article->toc))
 echo $this->article->toc;
echo "<div class=\"art-article\">";
echo $this->article->text;
echo "</div>";
if (intval($this->article->modified) !=0 && $this->params->get('show_modify_date')) {
 echo "<p class=\"modifydate\">";
 echo JText::_('Last Updated' ) . ' (' . JHTML::_('date', $this->article->modified, JText::_('DATE_FORMAT_LC2')) . ')';
 echo "</p>";
}
echo "<span class=\"article_separator\">&nbsp;</span>";
echo $this->article->event->afterDisplayContent;
echo "\r\n</div>\r\n<div class=\"cleared\"></div>\r\n";
?>

</div>

    </div>
</div>

