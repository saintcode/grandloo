// UK lang variables
//Older tiny2 lang file. Can be deleted